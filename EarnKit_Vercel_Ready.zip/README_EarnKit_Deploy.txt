EARNKIT — STATIC SITE DEPLOYMENT PACKAGE
=======================================

This folder is prepared for Vercel static hosting.

Files:
- index.html: main EarnKit app entry point.
- EarnKit_V20_Supabase_Backend.html: retained named copy of the main app.
- EarnKit_Admin_Panel.html: owner/admin console; keep beside index.html.
- vercel.json: static routes and no-cache response headers.
- BACKEND_STATUS_EarnKit.txt: backend status and remaining integration limits.

Backend:
- Supabase project: earnkit (bsdlwdliutuywxijlcgm), Mumbai region.
- API endpoint: https://bsdlwdliutuywxijlcgm.supabase.co/functions/v1/earnkit-api
- The Telegram bot token is not included in these files or this package; it remains stored server-side in Supabase Vault.

Current functional limits:
- The app must be opened as a Telegram Mini App so Telegram initData is available.
- The first owner admin enrollment still requires the one-time owner setup code supplied in the private ChatGPT conversation.
- Ad-funded credits are held for review until trusted provider callbacks are integrated.
- Withdrawals are recorded for admin review; automatic outgoing payment provider is not connected.

Deployment status:
- This archive is deployment-ready, but it is not itself a live hosted site.
- Publishing requires an authorized hosting account/connection. Vercel integration must be connected in ChatGPT before deployment can be made to your account. After connection, deploy the folder contents as a static site; no build step is required.
