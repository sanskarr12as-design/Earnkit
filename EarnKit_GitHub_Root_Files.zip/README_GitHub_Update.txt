EarnKit – Updated deployment files
==================================

The updated main app is index.html. It links the Admin Console to:
https://earnkit-admin-hackers4.vercel.app/

Current standalone admin panel:
https://earnkit-admin-hackers4.vercel.app/

Vercel main app deployment:
https://earnkit-app.vercel.app/

For GitHub Pages: replace the repository-root index.html with this package's index.html and commit. GitHub Pages will still use the content of the repository; uploading a ZIP alone does not update the page.

For Vercel: place index.html, EarnKit_Admin_Panel_Standalone.html, and vercel.json in the project's root. The included rewrite makes /admin open the standalone panel.

Admin requires Telegram Mini App initData. Open it from Telegram to provide the signed identity. Owner enrollment is first-use only and requires the private one-time bootstrap code already supplied in the chat.

Backend: Supabase Edge Function earnkit-api is active (version 8). Its random auth password now stays under Supabase Auth's 72-character password limit. Bot token remains stored in Supabase Vault and is not included in these files.

Limitations: rewarded-ad credits still need trusted provider-to-server verification. Payout marking records a manually sent payment; automatic bank/crypto payout is not configured. Live end-to-end Telegram login and every admin action have not been independently verified.
