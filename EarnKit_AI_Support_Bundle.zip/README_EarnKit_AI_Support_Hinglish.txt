# EarnKit AI Support — updated compact chat bundle

## What changed in this version
- Floating support button opens a smaller, right-side chat box that fits better on mobile.
- No pre-written AI greeting or canned question buttons. The message area starts empty; the agent replies only after a user sends a message.
- Gemini support prompt now covers the full EarnKit app context and replies in the user's language, including Hindi/Roman Hindi/Hinglish and English.
- The agent answers only EarnKit-related support questions; for unrelated questions, it politely redirects back to EarnKit.
- It is instructed not to invent balances, redeem-code validity, reward completion, withdrawal status or payment promises.
- Existing withdrawal flow was not intentionally changed.

## Files
- `EarnKit_AI_Support_Integrated.html` — existing EarnKit HTML with the compact support widget and notification hooks.
- `earnkit-ai-support/index.ts` — Supabase Edge Function source for Gemini chat and Telegram notifications.

## Live deployment status
The HTML currently uses `https://bsdlwdliutuywxijlcgm.supabase.co/functions/v1/earnkit-api` for the existing app backend. The support widget calls the same project reference at `/functions/v1/earnkit-ai-support`. In the connected Supabase integration, the available project reference did not match this existing backend project, so deployment to the correct project could not be confirmed. The chat will not give live Gemini answers until the Edge Function is deployed to the project actually used by the hosted HTML.

## Before deployment: rotate exposed credentials
The previous Telegram bot token and Gemini key were pasted into chat. Revoke them and create replacements before deployment. Do not paste new secrets in chat or in the HTML file.

## Deploy steps
1. Open the Supabase project whose reference matches the existing HTML backend (`bsdlwdliutuywxijlcgm`).
2. Deploy `earnkit-ai-support/index.ts` as an Edge Function named `earnkit-ai-support`.
3. Set these Edge Function secrets using the newly rotated credentials:
   - `TELEGRAM_BOT_TOKEN` = new BotFather token
   - `GEMINI_API_KEY` = new Google AI Studio key
   - `GEMINI_MODEL` = `gemini-3.6-flash`
4. The function has its own Telegram Mini App `initData` verification; configure the function with `verify_jwt = false` only because the function validates that Telegram payload itself.
5. Users who should receive Telegram notifications must open the bot and press **Start** first.
6. Upload this HTML to the same hosting destination already serving EarnKit and test inside Telegram.

## Important
- AI answers only after the user sends a message; it does not initiate conversation or auto-send an AI reply to Telegram.
- The notification function may deliver app-event notifications, but this bundle alone does not migrate locally stored Daily Bonus/redeem data into secure server-side claims. Those notifications must not be treated as authoritative payout records.
- Telegram notification delivery can fail if the user has not started the bot or if the service/API quota limit is reached.
- No live deployment is claimed in this bundle.
