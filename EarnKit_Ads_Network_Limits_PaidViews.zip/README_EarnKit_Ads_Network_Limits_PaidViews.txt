EarnKit — rewarded ads and referral update

Direct Mini App link
- https://t.me/KingFaucetBot/EarnKit
- Personal referral links use the same Mini App path plus ?startapp=ref_<TelegramUserID>.
- The separate Telegram channel link (mininghub4) is preserved; it is not used as the Mini App/referral base.

Referral tracking and rewards
- The backend reads the referral code from Telegram's HMAC-verified initData start_param; it does not trust a referrer ID supplied by the browser.
- A distinct existing referrer can receive a $0.02538 join reward when a new Telegram-linked account arrives through a valid referral link.
- The referral is qualified and credited automatically. A unique referral/ledger key prevents duplicate join credits.
- Qualified referrals generate a 30% commission on the referred user's positive, server-credited rewarded-ad cash earnings. No commission is paid for failed views, non-ad rewards, or the commission row itself.
- Attribution for a new account expires after 24 hours if no referral was recorded, and self-referrals are rejected.
- Referral totals count qualified joins. The new user's separate $0.005 welcome reward remains available through the app's existing welcome-reward flow.

Server-enforced ad rules (India time)
- GigaPub: maximum 5 successfully completed rewarded ads per Telegram account per India calendar day, across placements.
- OnClickA: maximum 25 successfully completed and server-confirmed views per account per India calendar day, across placements. The private OnClickA callback endpoint must be set in publisher/spot settings.
- Adexium: server task completion check with a 200-second cooldown across placements. Verify that 14168 is the actual task/widget ID in the publisher dashboard.
- Monetag: cash reward requires both SDK completion and a secret-protected server postback confirming a valued impression.
- Failed/closed attempts should not consume a successful-view cap.

Security
- Never put the private OnClickA callback URL/secret in public GitHub or HTML.
- The callback URL lives in a separate private text file and should only be configured in the ad network's publisher callback field.
- GigaPub's SDK completion signal and Adexium's task-check confirm completion; they are not a guarantee of final publisher revenue settlement.

Deployment
- Replace the existing root index.html in the Earnkit repository with this index.html.
- Keep index.html in the repository root and publish the main branch root using GitHub Pages.
- Supabase earnkit-api v14 is active; the server-only referral registration and 30% ad-commission trigger are deployed separately.
- After upload, reopen the Mini App from https://t.me/KingFaucetBot/EarnKit to test with fresh Telegram initData.
