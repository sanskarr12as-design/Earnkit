EarnKit network limits & verified-view patch

File
- index.html: updated single-file Telegram Mini App.

Server-enforced rules (India time)
- GigaPub: maximum 5 successfully completed rewarded ads per Telegram account per India calendar day, across Watch Ads, Spin, Scratch and task placements.
- OnClickA: maximum 25 successfully completed and server-confirmed views per account per India calendar day, across all placements. This follows OnClickA's publisher recommendation. The server-view callback URL must be configured in the OnClickA publisher/spot handler or shared with the OnClickA account manager.
- Adexium: the app uses `requestRewardedAd('interstitial')`, checks completion through Adexium's server task-check endpoint, and enforces a 200-second cooldown across placements.
- Monetag: cash reward is credited only when the SDK completion and Monetag's server postback match a paid `valued` impression. Non-valued impressions are not credited. No fixed publisher per-user daily cap was found in the public SDK docs, so the app does not invent one.
- Failed/closed attempts are marked rejected when possible so they do not consume a successful-view cap.

OnClickA callback setup
- The separate private file `EarnKit_OnClickA_View_Callback_URL.txt` contains the OnClickA server-view confirmation URL. Set it as the handler/callback URL in OnClickA publisher settings, where OnClickA appends `?USERID=<Telegram user ID>`. If that setting is not available in the dashboard, ask the OnClickA account manager to register it.
- Until the callback is configured and working, OnClickA ads may display, but EarnKit intentionally will not credit them based only on the browser Promise.

Important limits of verification
- GigaPub's public TMA quick-start documents a `showGiga()` Promise and says to run reward logic when it resolves; it does not document a per-view paid-revenue postback for that format. EarnKit checks that completion signal and enforces the 5/day cap, but cannot know from the SDK alone whether a later publisher ledger adjustment changes GigaPub's payable revenue.
- Adexium's task-check endpoint confirms completion, not a per-view final publisher payment amount.
- Monetag supplies a server-side `valued`/`non_valued` marker, so that is the strictest paid-impression verification in this setup.
- Publisher revenue is settled separately. Never promise a fixed revenue amount per ad view.

Deployment
- Publish this `index.html` to the actual Telegram Mini App hosting location to activate frontend changes.
- Supabase backend rules are deployed separately and are already active.
